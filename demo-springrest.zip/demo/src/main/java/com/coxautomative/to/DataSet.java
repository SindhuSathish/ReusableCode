package com.coxautomative.to;

public class DataSet {

	private String dataSetID;

	public String getDataSetID() {
		return dataSetID;
	}

	public void setDataSetID(String dataSetID) {
		this.dataSetID = dataSetID;
	}
	
	
}
