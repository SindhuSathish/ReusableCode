package com.coxautomative.to;

import java.util.List;

public class Dealers {
	
	private List<DealerAnswer> dealerAnswer;

	public List<DealerAnswer> getDealerAnswer() {
		return dealerAnswer;
	}

	public void setDealerAnswer(List<DealerAnswer> dealerAnswer) {
		this.dealerAnswer = dealerAnswer;
	}
	
	

}
