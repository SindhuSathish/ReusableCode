package com.coxautomative.model;

import java.util.ArrayList;
import java.util.List;

import com.coxautomative.to.DealerAnswer;;


public class DealerRegistration {

	private List<DealerAnswer> dealerAnswers;
	
	private static DealerRegistration dealerRegistation = null;
	
    private DealerRegistration(){
    	dealerAnswers = new ArrayList<DealerAnswer>();
		
		  DealerAnswer dealerAnswer = new DealerAnswer();
		  dealerAnswer.setDealerId(12345); dealerAnswer.setName("Dealer1");
		  dealerAnswers.add(dealerAnswer);
		 
    }
    
    public static DealerRegistration getInstance() {
        if(dealerRegistation == null) {
        	dealerRegistation = new DealerRegistration();
              return dealerRegistation;
            }
            else {
                return dealerRegistation;
            }
    }
    
    public void add(DealerAnswer dealerAnswer) {
    	dealerAnswers.add(dealerAnswer);
        }
    

	public String upDateDealer(DealerAnswer dealerAnswer) {
	for(int i=0; i<dealerAnswers.size(); i++)
	        {
		DealerAnswer dealerToUpdate = dealerAnswers.get(i);
	            if(dealerToUpdate.getDealerId()==(dealerAnswer.getDealerId())) {
	            	dealerAnswers.set(i, dealerToUpdate);//update the new record
	              return "Update successful";
	            }
	        }
	return "Update un-successful";
	}
	
	
	public List<DealerAnswer> getDealerRecords() {
	return dealerAnswers;
	}

	
	/*
	 * public List<DealerAnswer> addDataSet(String datasetId) { // TODO
	 * Auto-generated method stub return null; }
	 */
    
   
}