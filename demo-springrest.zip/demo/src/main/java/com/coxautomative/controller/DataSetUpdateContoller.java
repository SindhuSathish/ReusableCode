package com.coxautomative.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.coxautomative.model.DealerRegistration;
import com.coxautomative.to.DealerAnswer;

@Controller
public class DataSetUpdateContoller {
	
	@RequestMapping(method = RequestMethod.POST, value="/api/datasetId")
	@ResponseBody
	public List<DealerAnswer> getAllStudents() {
	  return DealerRegistration.getInstance().getDealerRecords();
	  }

}
